# This is a fork from original BSDS by [Crazor](https://github.com/CrazorTheCat)  with a lot less features, it is meant for developement, do not use for production and hosting for others.

Discord link : https://discord.gg/mt4dUxXryh

iOS : https://mega.nz/file/Mx8TjLZD#vq1wXa9peJ0EKTXoS9pr-J1Wgij764YKBk_tCZ7FyWc    decryption key in case mega ask it : vq1wXa9peJ0EKTXoS9pr-J1Wgij764YKBk_tCZ7FyWc

Second link : https://www.mediafire.com/file/4cwiggqrkxq694b/BSDS_V48.ipa/file

Android : https://www.mediafire.com/file/2fzu156tq0fo2yp/BSDS-V48.apk/file


## Requirements: ##
1. a brain...

## How to play BSDS: ##
1: download server and client

2: extract client and go to Frameworks folder and open BSDS.config

2.1: change the ipv4 address of your device you execute the server from

2.2: save and compile back to ipa format.

3: install the client using your favorite app installer.

4: open terminal on your computer and go to BSDS directory.

5: now you need to install crypto module.

5.1: type cd Classes/Crypto

5.2: now type python setup.py install

6: go back to BSDS root directory.

7: type python Core.py

8: now open the game and play.

![IMG_0550](https://user-images.githubusercontent.com/72312877/227719466-2b6f2f48-6dfe-4059-aec7-507583287412.PNG)

## credits ##
[Shadow#9418](https://github.com/ShadowwDev) Android Client

[S.B#0056](https://github.com/HaccerCat) for his help with crypto and client

[Vitalik](https://github.com/VitalikObject) for his crypto from [OldBrawl](https://github.com/VitalikObject/OldBrawl)
